// Smart Crop Advisor - Agricultural Recommendation System

// Crop data from the provided JSON
const cropData = {
    "Rice": {
        "optimal_conditions": {
            "nitrogen": [80, 120],
            "phosphorus": [40, 70],
            "potassium": [40, 70],
            "temperature": [20, 35],
            "humidity": [80, 95],
            "ph": [5.5, 7.0],
            "rainfall": [150, 300]
        },
        "description": "Staple grain crop requiring high humidity and adequate water",
        "yield": "3-6 tons/hectare",
        "season": "Monsoon season (June-October)",
        "benefits": ["High yield potential", "Staple food crop", "Good market demand"],
        "icon": "🌾"
    },
    "Wheat": {
        "optimal_conditions": {
            "nitrogen": [80, 120],
            "phosphorus": [40, 70],
            "potassium": [40, 70],
            "temperature": [12, 25],
            "humidity": [50, 70],
            "ph": [6.0, 7.5],
            "rainfall": [50, 100]
        },
        "description": "Major cereal grain crop grown in cooler climates",
        "yield": "2-4 tons/hectare",
        "season": "Winter season (November-April)",
        "benefits": ["Excellent market value", "Storage friendly", "Multiple varieties available"],
        "icon": "🌾"
    },
    "Corn": {
        "optimal_conditions": {
            "nitrogen": [100, 140],
            "phosphorus": [50, 80],
            "potassium": [50, 80],
            "temperature": [18, 32],
            "humidity": [60, 85],
            "ph": [5.8, 7.2],
            "rainfall": [80, 150]
        },
        "description": "Versatile crop used for food, feed, and industrial purposes",
        "yield": "4-8 tons/hectare",
        "season": "Summer season (April-September)",
        "benefits": ["High yield", "Multiple uses", "Good drought tolerance"],
        "icon": "🌽"
    },
    "Cotton": {
        "optimal_conditions": {
            "nitrogen": [100, 130],
            "phosphorus": [60, 90],
            "potassium": [80, 120],
            "temperature": [21, 32],
            "humidity": [50, 80],
            "ph": [5.8, 8.0],
            "rainfall": [50, 100]
        },
        "description": "Cash crop fiber used in textile industry",
        "yield": "1-2 tons/hectare",
        "season": "Summer season (April-October)",
        "benefits": ["High market value", "Cash crop", "Industrial demand"],
        "icon": "🌿"
    },
    "Sugarcane": {
        "optimal_conditions": {
            "nitrogen": [120, 150],
            "phosphorus": [60, 90],
            "potassium": [80, 120],
            "temperature": [26, 35],
            "humidity": [70, 90],
            "ph": [6.5, 7.5],
            "rainfall": [150, 250]
        },
        "description": "Sugar-producing crop requiring warm climate and adequate water",
        "yield": "60-80 tons/hectare",
        "season": "Year-round (planted Feb-April)",
        "benefits": ["High tonnage yield", "Sugar industry demand", "By-products value"],
        "icon": "🎋"
    },
    "Soybean": {
        "optimal_conditions": {
            "nitrogen": [20, 40],
            "phosphorus": [30, 60],
            "potassium": [30, 60],
            "temperature": [20, 30],
            "humidity": [60, 80],
            "ph": [6.0, 7.0],
            "rainfall": [80, 140]
        },
        "description": "Legume crop rich in protein and oil content",
        "yield": "1.5-3 tons/hectare",
        "season": "Monsoon season (June-October)",
        "benefits": ["Nitrogen fixation", "High protein", "Oil extraction"],
        "icon": "🫘"
    },
    "Potato": {
        "optimal_conditions": {
            "nitrogen": [80, 120],
            "phosphorus": [50, 80],
            "potassium": [80, 120],
            "temperature": [15, 25],
            "humidity": [70, 85],
            "ph": [5.0, 6.5],
            "rainfall": [60, 120]
        },
        "description": "Tuber crop with high nutritional value and versatile uses",
        "yield": "15-25 tons/hectare",
        "season": "Winter season (October-March)",
        "benefits": ["High yield", "Nutritious", "Good storage life"],
        "icon": "🥔"
    },
    "Tomato": {
        "optimal_conditions": {
            "nitrogen": [100, 140],
            "phosphorus": [50, 80],
            "potassium": [100, 150],
            "temperature": [18, 29],
            "humidity": [65, 85],
            "ph": [6.0, 6.8],
            "rainfall": [60, 100]
        },
        "description": "Vegetable crop rich in vitamins and widely consumed",
        "yield": "25-40 tons/hectare",
        "season": "Year-round with proper care",
        "benefits": ["High market demand", "Rich in nutrients", "Year-round production"],
        "icon": "🍅"
    }
};

// Global variables
let currentParameters = {
    nitrogen: 80,
    phosphorus: 50,
    potassium: 60,
    temperature: 25,
    humidity: 65,
    ph: 6.5,
    rainfall: 100
};

let lastRecommendations = [];

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    console.log('Initializing Smart Crop Advisor...');

    initializeSliders();
    updateRealTimeFeedback();
    updateSoilHealth();

    // Set up navigation with proper event handling
    setupNavigation();

    // Make sure dashboard is active by default
    switchSection('dashboard');
});

// Setup navigation event handlers
function setupNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');

    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();

            const section = this.getAttribute('data-section');
            console.log('Navigating to:', section);

            if (section) {
                switchSection(section);
            }
        });
    });
}

// Navigation functions - Fixed version
function switchSection(sectionName) {
    console.log('Switching to section:', sectionName);

    // Update active nav link
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
    });

    const activeNavLink = document.querySelector(`[data-section="${sectionName}"]`);
    if (activeNavLink) {
        activeNavLink.classList.add('active');
    }

    // Show active section
    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
    });

    const targetSection = document.getElementById(sectionName);
    if (targetSection) {
        targetSection.classList.add('active');
        console.log('Section switched successfully to:', sectionName);
    } else {
        console.error('Section not found:', sectionName);
    }
}

// Initialize sliders and their event listeners
function initializeSliders() {
    const sliders = ['nitrogen', 'phosphorus', 'potassium', 'temperature', 'humidity', 'ph', 'rainfall'];

    sliders.forEach(param => {
        const slider = document.getElementById(param);
        const valueDisplay = document.getElementById(param + 'Value');

        if (slider && valueDisplay) {
            // Set initial value
            slider.value = currentParameters[param];
            updateParameterDisplay(param, currentParameters[param]);

            // Add event listener
            slider.addEventListener('input', function() {
                const value = parseFloat(this.value);
                currentParameters[param] = value;
                updateParameterDisplay(param, value);
                updateRealTimeFeedback();
                updateSoilHealth();
            });
        }
    });
}

// Update parameter display values
function updateParameterDisplay(param, value) {
    const valueDisplay = document.getElementById(param + 'Value');
    if (valueDisplay) {
        let displayValue = value;
        let unit = '';

        switch (param) {
            case 'nitrogen':
            case 'phosphorus':
            case 'potassium':
                unit = ' kg/ha';
                break;
            case 'temperature':
                unit = '°C';
                break;
            case 'humidity':
                unit = '%';
                break;
            case 'ph':
                displayValue = value.toFixed(1);
                break;
            case 'rainfall':
                unit = ' mm';
                break;
        }

        valueDisplay.textContent = displayValue + unit;
    }
}

// Calculate suitability score for a crop
function calculateSuitability(cropName, parameters) {
    const crop = cropData[cropName];
    if (!crop) return 0;

    const conditions = crop.optimal_conditions;
    let totalScore = 0;
    let paramCount = 0;

    Object.keys(parameters).forEach(param => {
        if (conditions[param]) {
            const [min, max] = conditions[param];
            const value = parameters[param];

            let score = 0;
            if (value >= min && value <= max) {
                // Perfect range
                score = 100;
            } else {
                // Calculate how far off we are
                const range = max - min;
                const tolerance = range * 0.3; // 30% tolerance outside range

                if (value < min) {
                    const distance = min - value;
                    score = Math.max(0, 100 - (distance / tolerance) * 100);
                } else {
                    const distance = value - max;
                    score = Math.max(0, 100 - (distance / tolerance) * 100);
                }
            }

            totalScore += score;
            paramCount++;
        }
    });

    return paramCount > 0 ? Math.round(totalScore / paramCount) : 0;
}

// Update real-time feedback indicators
function updateRealTimeFeedback() {
    // Calculate nutrient balance
    const nutrients = [currentParameters.nitrogen, currentParameters.phosphorus, currentParameters.potassium];
    const avgNutrients = nutrients.reduce((a, b) => a + b) / nutrients.length;
    const nutrientBalance = Math.min(100, (avgNutrients / 120) * 100);

    // Calculate climate suitability
    const tempScore = currentParameters.temperature >= 15 && currentParameters.temperature <= 35 ? 100 : 60;
    const humidityScore = currentParameters.humidity >= 50 && currentParameters.humidity <= 90 ? 100 : 70;
    const rainfallScore = currentParameters.rainfall >= 50 && currentParameters.rainfall <= 200 ? 100 : 75;
    const climateScore = (tempScore + humidityScore + rainfallScore) / 3;

    // Calculate soil quality
    const phScore = currentParameters.ph >= 6.0 && currentParameters.ph <= 7.5 ? 100 : 80;
    const soilScore = (nutrientBalance + phScore) / 2;

    // Update progress bars
    updateProgressBar('nutrientProgress', 'nutrientValue', nutrientBalance);
    updateProgressBar('climateProgress', 'climateValue', climateScore);
    updateProgressBar('soilProgress', 'soilValue', soilScore);
}

// Update progress bar display
function updateProgressBar(barId, valueId, score) {
    const progressBar = document.getElementById(barId);
    const valueElement = document.getElementById(valueId);

    if (progressBar && valueElement) {
        progressBar.style.width = score + '%';

        let label = 'Poor';
        if (score >= 80) label = 'Excellent';
        else if (score >= 65) label = 'Good';
        else if (score >= 45) label = 'Fair';

        valueElement.textContent = label;
        valueElement.className = 'progress-value';

        if (score >= 80) valueElement.style.color = 'var(--color-success)';
        else if (score >= 65) valueElement.style.color = 'var(--color-primary)';
        else if (score >= 45) valueElement.style.color = 'var(--color-warning)';
        else valueElement.style.color = 'var(--color-error)';
    }
}

// Update soil health meter
function updateSoilHealth() {
    const meterElement = document.getElementById('soilMeter');
    const meterValue = document.querySelector('.meter-value');

    if (meterElement && meterValue) {
        // Calculate overall soil health
        const nutrients = [currentParameters.nitrogen, currentParameters.phosphorus, currentParameters.potassium];
        const avgNutrients = nutrients.reduce((a, b) => a + b) / nutrients.length;
        const nutrientScore = Math.min(100, (avgNutrients / 120) * 100);
        const phScore = currentParameters.ph >= 6.0 && currentParameters.ph <= 7.5 ? 100 : 80;
        const overallScore = Math.round((nutrientScore + phScore) / 2);

        // Update meter display
        meterValue.textContent = overallScore + '%';

        // Update meter circle color
        const angle = (overallScore / 100) * 360;
        let color = 'var(--color-error)';
        if (overallScore >= 80) color = 'var(--color-success)';
        else if (overallScore >= 65) color = 'var(--color-primary)';
        else if (overallScore >= 45) color = 'var(--color-warning)';

        meterElement.style.background = `conic-gradient(${color} 0deg, ${color} ${angle}deg, var(--color-secondary) ${angle}deg)`;
    }
}

// Get crop recommendations
function getRecommendations() {
    console.log('Getting recommendations with parameters:', currentParameters);
    showLoading();

    // Simulate processing time
    setTimeout(() => {
        const recommendations = [];

        // Calculate suitability for each crop
        Object.keys(cropData).forEach(cropName => {
            const suitability = calculateSuitability(cropName, currentParameters);
            if (suitability > 0) {
                recommendations.push({
                    name: cropName,
                    suitability: suitability,
                    data: cropData[cropName]
                });
            }
        });

        // Sort by suitability score
        recommendations.sort((a, b) => b.suitability - a.suitability);

        // Keep top 6 recommendations
        lastRecommendations = recommendations.slice(0, 6);

        console.log('Generated recommendations:', lastRecommendations);

        // Display recommendations
        displayRecommendations(lastRecommendations);

        hideLoading();
        switchSection('results');
    }, 2000);
}

// Display recommendations
function displayRecommendations(recommendations) {
    const grid = document.getElementById('recommendationsGrid');
    if (!grid) return;

    grid.innerHTML = '';

    if (recommendations.length === 0) {
        grid.innerHTML = '<p class="no-results">No suitable crops found for your parameters. Try adjusting your inputs.</p>';
        return;
    }

    recommendations.forEach((rec, index) => {
        const card = createCropCard(rec, index + 1);
        grid.appendChild(card);
    });
}

// Create crop recommendation card
function createCropCard(recommendation, rank) {
    const {
        name,
        suitability,
        data
    } = recommendation;

    const card = document.createElement('div');
    card.className = 'card crop-card';

    let suitabilityClass = 'good';
    if (suitability >= 80) suitabilityClass = 'excellent';
    else if (suitability < 50) suitabilityClass = 'poor';

    card.innerHTML = `
    <div class="crop-rank">${rank}</div>
    <div class="crop-image">
      <span style="font-size: 4rem;">${data.icon}</span>
    </div>
    <div class="crop-content">
      <div class="crop-header">
        <h3 class="crop-name">${name}</h3>
        <div class="crop-suitability">
          <div class="suitability-bar">
            <div class="suitability-fill" style="width: ${suitability}%"></div>
          </div>
          <span class="suitability-value">${suitability}%</span>
        </div>
      </div>
      
      <p class="crop-description">${data.description}</p>
      
      <div class="crop-details">
        <div class="detail-item">
          <div class="detail-label">Expected Yield</div>
          <div class="detail-value">${data.yield}</div>
        </div>
        <div class="detail-item">
          <div class="detail-label">Growing Season</div>
          <div class="detail-value">${data.season}</div>
        </div>
      </div>
      
      <div class="crop-benefits">
        <ul class="benefits-list">
          ${data.benefits.map(benefit => `<li>${benefit}</li>`).join('')}
        </ul>
      </div>
      
      <div class="crop-actions">
        <button class="btn btn--outline btn--sm" onclick="addToComparison('${name}')">
          <i class="fas fa-plus"></i> Compare
        </button>
        <button class="btn btn--primary btn--sm" onclick="showCropDetails('${name}')">
          <i class="fas fa-info-circle"></i> Details
        </button>
      </div>
    </div>
  `;

    return card;
}

// Reset parameters to default values
function resetParameters() {
    currentParameters = {
        nitrogen: 80,
        phosphorus: 50,
        potassium: 60,
        temperature: 25,
        humidity: 65,
        ph: 6.5,
        rainfall: 100
    };

    // Update sliders
    Object.keys(currentParameters).forEach(param => {
        const slider = document.getElementById(param);
        if (slider) {
            slider.value = currentParameters[param];
            updateParameterDisplay(param, currentParameters[param]);
        }
    });

    updateRealTimeFeedback();
    updateSoilHealth();
}

// Show loading overlay
function showLoading() {
    const overlay = document.getElementById('loadingOverlay');
    if (overlay) {
        overlay.classList.add('active');
    }
}

// Hide loading overlay
function hideLoading() {
    const overlay = document.getElementById('loadingOverlay');
    if (overlay) {
        overlay.classList.remove('active');
    }
}

// Comparison functionality
let comparisonCrops = [];

function addToComparison(cropName) {
    if (!comparisonCrops.includes(cropName)) {
        comparisonCrops.push(cropName);

        if (comparisonCrops.length >= 2) {
            showComparison();
        } else {
            alert(`${cropName} added to comparison. Add another crop to see comparison table.`);
        }
    } else {
        alert(`${cropName} is already in comparison.`);
    }
}

function showComparison() {
    const comparisonCard = document.getElementById('comparisonCard');
    const comparisonTable = document.getElementById('comparisonTable');

    if (!comparisonCard || !comparisonTable) return;

    // Create comparison table
    let tableHTML = `
    <table class="comparison-table">
      <thead>
        <tr>
          <th>Parameter</th>
          ${comparisonCrops.map(crop => `<th>${crop}</th>`).join('')}
        </tr>
      </thead>
      <tbody>
        <tr>
          <td><strong>Suitability</strong></td>
          ${comparisonCrops.map(crop => {
            const rec = lastRecommendations.find(r => r.name === crop);
            return `<td>${rec ? rec.suitability + '%' : 'N/A'}</td>`;
          }).join('')}
        </tr>
        <tr>
          <td><strong>Expected Yield</strong></td>
          ${comparisonCrops.map(crop => `<td>${cropData[crop].yield}</td>`).join('')}
        </tr>
        <tr>
          <td><strong>Growing Season</strong></td>
          ${comparisonCrops.map(crop => `<td>${cropData[crop].season}</td>`).join('')}
        </tr>
        <tr>
          <td><strong>Key Benefits</strong></td>
          ${comparisonCrops.map(crop => `<td>${cropData[crop].benefits.slice(0, 2).join(', ')}</td>`).join('')}
        </tr>
      </tbody>
    </table>
  `;

    comparisonTable.innerHTML = tableHTML;
    comparisonCard.style.display = 'block';
}

function hideComparison() {
    const comparisonCard = document.getElementById('comparisonCard');
    if (comparisonCard) {
        comparisonCard.style.display = 'none';
        comparisonCrops = [];
    }
}

// Export functionality
function exportResults() {
    if (lastRecommendations.length === 0) {
        alert('Please generate recommendations first!');
        return;
    }

    // Create a simple text export (in a real app, this would generate a proper PDF)
    let exportText = 'SMART CROP ADVISOR - RECOMMENDATIONS REPORT\n';
    exportText += '='.repeat(50) + '\n\n';

    exportText += 'INPUT PARAMETERS:\n';
    exportText += `-Nitrogen: ${currentParameters.nitrogen} kg/ha\n`;
    exportText += `-Phosphorus: ${currentParameters.phosphorus} kg/ha\n`;
    exportText += `-Potassium: ${currentParameters.potassium} kg/ha\n`;
    exportText += `-Temperature: ${currentParameters.temperature}°C\n`;
    exportText += `-Humidity: ${currentParameters.humidity}%\n`;
    exportText += `-pH: ${currentParameters.ph}\n`;
    exportText += `-Rainfall: ${currentParameters.rainfall} mm\n\n`;

    exportText += 'TOP CROP RECOMMENDATIONS:\n';
    exportText += '-'.repeat(30) + '\n';

    lastRecommendations.forEach((rec, index) => {
        exportText += `${index + 1}. ${rec.name} (${rec.suitability}% suitable)\n`;
        exportText += `   Yield: ${rec.data.yield}\n`;
        exportText += `   Season: ${rec.data.season}\n`;
        exportText += `   Benefits: ${rec.data.benefits.join(', ')}\n\n`;
    });

    // Create and download file
    const blob = new Blob([exportText], {
        type: 'text/plain'
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'crop-recommendations.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    alert('Report exported successfully!');
}

// Save profile functionality (using localStorage in real app)
function saveProfile() {
    const profileData = {
        parameters: currentParameters,
        timestamp: new Date().toISOString(),
        location: document.getElementById('location').value || 'Unknown'
    };

    // In a real app, this would save to a backend
    console.log('Saving profile:', profileData);
    alert('Profile saved successfully! (This is a demo - data saved to console)');
}

// Show crop details (placeholder)
function showCropDetails(cropName) {
    const crop = cropData[cropName];
    if (!crop) return;

    let detailsText = `${cropName} - Detailed Information\n\n`;
    detailsText += `Description: ${crop.description}\n\n`;
    detailsText += `Optimal Conditions:\n`;
    detailsText += `-Nitrogen: ${crop.optimal_conditions.nitrogen[0]}-${crop.optimal_conditions.nitrogen[1]} kg/ha\n`;
    detailsText += `-Phosphorus: ${crop.optimal_conditions.phosphorus[0]}-${crop.optimal_conditions.phosphorus[1]} kg/ha\n`;
    detailsText += `-Potassium: ${crop.optimal_conditions.potassium[0]}-${crop.optimal_conditions.potassium[1]} kg/ha\n`;
    detailsText += `-Temperature: ${crop.optimal_conditions.temperature[0]}-${crop.optimal_conditions.temperature[1]}°C\n`;
    detailsText += `-Humidity: ${crop.optimal_conditions.humidity[0]}-${crop.optimal_conditions.humidity[1]}%\n`;
    detailsText += `-pH: ${crop.optimal_conditions.ph[0]}-${crop.optimal_conditions.ph[1]}\n`;
    detailsText += `-Rainfall: ${crop.optimal_conditions.rainfall[0]}-${crop.optimal_conditions.rainfall[1]} mm\n\n`;
    detailsText += `Expected Yield: ${crop.yield}\n`;
    detailsText += `Growing Season: ${crop.season}\n`;
    detailsText += `Key Benefits: ${crop.benefits.join(', ')}`;

    alert(detailsText);
}

// Make functions globally available for onclick handlers
window.switchSection = switchSection;
window.getRecommendations = getRecommendations;
window.resetParameters = resetParameters;
window.addToComparison = addToComparison;
window.hideComparison = hideComparison;
window.exportResults = exportResults;
window.saveProfile = saveProfile;
window.showCropDetails = showCropDetails;